# Lumen Vault

The Vault is append-only by default.

Do not delete records.
Do not rewrite history.
Do not purge continuity.
Do not remove founder-approved settings.

New records are appended to:

- `vault/append-only/lumen-vault.jsonl`
- `vault/decisions/`
- `vault/builds/`
- `vault/recommendations/`
- `vault/patches/`
- `vault/audit/`
