# GitHub Setup for Lumen

Recommended:

- Private repository.
- GitHub is source control + append-only Vault + version history.
- Use GitHub Secrets for Cloudflare/OpenAI tokens.
- Use branch protections before production use.
- Avoid deleting Vault history.
- Lumen commits additive changes only by default.

Required GitHub secrets:

- CLOUDFLARE_API_TOKEN
- CLOUDFLARE_ACCOUNT_ID
- OPENAI_API_KEY
- LUMEN_SETUP_PASSWORD or equivalent local-only unlock secret
