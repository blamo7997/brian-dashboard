# Cloudflare Token Profile

Brian chose one broad Cloudflare token for Lumen.

Configured principle:

- Everything possible set to Admin/Edit for Cloudflare front-end and infrastructure authority.
- Billing set to Read.
- Registrar was set to Read.
- Lumen uses Cloudflare as frontend/deployment, not as the only Vault source.
- GitHub remains source/Vault/version history.
- OpenAI remains intelligence.

Store token only in:
- Lumen encrypted setup
- GitHub Actions secret: CLOUDFLARE_API_TOKEN
- Cloudflare secret store where appropriate
