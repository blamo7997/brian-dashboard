export async function askOpenAI({ apiKey, messages, model = "gpt-4.1" }) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ model, input: messages })
    });
    return await response.json();
  } finally {
    clearTimeout(timeout);
  }
}
