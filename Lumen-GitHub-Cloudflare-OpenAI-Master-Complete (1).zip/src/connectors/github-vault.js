export async function appendToGitHubVault({ token, owner, repo, path, content, message }) {
  const api = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
  const current = await fetch(api, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" }
  });

  let existing = "";
  let sha = undefined;
  if (current.ok) {
    const data = await current.json();
    sha = data.sha;
    existing = atob(data.content.replace(/\n/g, ""));
  }

  const next = existing + JSON.stringify({
    timestamp: new Date().toISOString(),
    ...content
  }) + "\n";

  const res = await fetch(api, {
    method: "PUT",
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json", "Content-Type": "application/json" },
    body: JSON.stringify({
      message: message || "Append Lumen Vault record",
      content: btoa(next),
      sha
    })
  });

  return await res.json();
}
