async function call(path){
  const r = await fetch(path, { headers: { "x-lumen-client": "frontend" }});
  return await r.json();
}
document.getElementById("health").onclick = async()=> {
  document.getElementById("output").textContent = JSON.stringify(await call("/api/health"), null, 2);
};
document.getElementById("next").onclick = async()=> {
  document.getElementById("output").textContent = JSON.stringify(await call("/api/recommend-next-layer"), null, 2);
};
