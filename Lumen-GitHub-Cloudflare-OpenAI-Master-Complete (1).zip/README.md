# Lumen Master Repository

This repository is designed for Lumen with the architecture Brian specified:

- **OpenAI** = intelligence layer / ChatGPT-compatible brain
- **GitHub** = source control, Vault, append-only continuity, version history
- **Cloudflare** = front end, deployment, Workers/Pages/service layer
- **Local Vault** = offline fallback
- **Lumen Desktop EXE** = founder-controlled operating interface

## Permanent Lumen Rules

1. Lumen checks the Vault first.
2. The Vault is append-only by default.
3. Lumen preserves existing features, products, memberships, permissions, records, and founder-approved settings.
4. Lumen never removes, replaces, purges, or deprecates unless the founder explicitly approves.
5. Lumen never hangs indefinitely.
6. Lumen uses timeouts, watchdogs, retries, queues, offline fallback, and user-visible status.
7. Lumen recommends next layers from Vault analysis.
8. Founder may approve with: **Add Next Layer**.
9. Lumen may auto-patch only through safe, additive, logged changes or founder-approved changes.
10. Cloudflare is the front-end/deployment layer.
11. GitHub is the source/Vault/version history layer.
12. OpenAI remains the primary intelligence layer unless founder adds another provider.

## What This Package Includes

- Cloudflare Pages frontend
- Cloudflare Worker API scaffold
- GitHub append-only Vault layout
- Local encrypted Vault scaffolding
- Lumen setup wizard schema
- OpenAI connector scaffold
- GitHub connector scaffold
- Cloudflare connector scaffold
- Anti-hang watchdog logic
- Add Next Layer workflow
- Auto-patch recommendation workflow
- GitHub Actions workflow
- Wrangler config template
- Environment variable templates
- Security and continuity policies

## Secrets

This package intentionally does not include live API tokens. Lumen setup stores tokens via its encrypted local setup flow and GitHub/Cloudflare secrets.
