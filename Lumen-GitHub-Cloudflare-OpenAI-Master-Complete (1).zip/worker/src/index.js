const RULES = {
  openAIPrimaryBrain: true,
  githubVault: true,
  cloudflareFrontend: true,
  vaultFirst: true,
  appendOnly: true,
  additiveOnly: true,
  neverRemoveWithoutFounderApproval: true,
  antiHang: true
};

function timeout(ms, label) {
  return new Promise(resolve => setTimeout(() => resolve({
    ok: false,
    label,
    timeout: true,
    message: "Timed out safely. Lumen continued instead of hanging."
  }), ms));
}

async function safeJson(payload, status = 200) {
  return new Response(JSON.stringify(payload, null, 2), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" }
  });
}

async function appendVault(env, record) {
  const item = {
    timestamp: new Date().toISOString(),
    ...record,
    rules: RULES
  };

  if (env.LUMEN_VAULT_KV) {
    const key = `vault/${Date.now()}-${crypto.randomUUID()}.json`;
    await env.LUMEN_VAULT_KV.put(key, JSON.stringify(item));
  }

  // GitHub append is intentionally routed through setup-configured token.
  // Lumen Desktop should store the GitHub token securely and call a protected endpoint
  // after founder approval. Do not hardcode secrets here.

  return item;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/health") {
      const result = await Promise.race([
        appendVault(env, {
          type: "health-check",
          payload: {
            ok: true,
            message: "Lumen Cloudflare Worker is reachable.",
            cloudflare: "frontend/deployment layer",
            github: "source/Vault/version history layer",
            openai: "primary intelligence layer"
          }
        }),
        timeout(8000, "cloudflare-worker-health")
      ]);
      return safeJson(result);
    }

    if (url.pathname === "/api/recommend-next-layer") {
      const recommendation = {
        type: "next-layer-recommendation",
        payload: {
          layer: "Online Vault Sync + OpenAI Connector",
          adds: [
            "GitHub append-only Vault commit queue",
            "OpenAI API connector",
            "Cloudflare deployment status panel",
            "encrypted local setup wizard",
            "future connector prompt framework"
          ],
          removes: [],
          requiresFounderApproval: true
        }
      };
      return safeJson(await appendVault(env, recommendation));
    }

    if (url.pathname === "/api/vault/append" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      return safeJson(await appendVault(env, {
        type: body.type || "manual-append",
        payload: body.payload || body
      }));
    }

    return safeJson({ ok: true, app: "Lumen", rules: RULES });
  }
};
