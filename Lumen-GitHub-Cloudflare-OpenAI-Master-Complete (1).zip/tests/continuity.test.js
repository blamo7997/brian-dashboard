import fs from "fs";

const rules = JSON.parse(fs.readFileSync("./lumen.rules.json", "utf8")).lumen;
const required = [
  "cloudflareFirstFrontend",
  "githubSourceAndVault",
  "openAIPrimaryBrain",
  "vaultFirst",
  "appendOnlyVault",
  "additiveOnly",
  "neverRemoveWithoutFounderApproval",
  "neverHang"
];

for (const key of required) {
  if (rules[key] !== true) {
    console.error(`Missing required rule: ${key}`);
    process.exit(1);
  }
}

console.log("Lumen continuity rules validated.");
