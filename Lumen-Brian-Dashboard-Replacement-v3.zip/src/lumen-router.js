const LUMEN_RULES = {
  software: "Lumen",
  frontend: "Cloudflare Workers",
  source: "GitHub",
  vaultMode: "append-only",
  additiveOnly: true,
  noDeleteByDefault: true,
  preserveExisting: true,
  antiHang: true,
  openAIReady: true,
  noEmbeddedSecrets: true
};

export async function handleLumenRequest(request, env, ctx) {
  const url = new URL(request.url);

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }

  if (url.pathname === "/health") {
    return json({
      ok: true,
      service: "Brian Dashboard",
      routedThrough: "Lumen",
      status: "online",
      mode: "worker-api",
      rules: LUMEN_RULES,
      timestamp: new Date().toISOString()
    });
  }

  if (url.pathname === "/lumen/status") {
    return json({
      ok: true,
      lumen: {
        softwareLayer: "active",
        openAI: env.OPENAI_API_KEY ? "configured" : "not_configured",
        githubVault: "repository-backed",
        cloudflareFrontend: "active",
        localFallback: "desktop-app-managed",
        vaultPath: "vault/lumen-vault.append-only.jsonl"
      },
      rules: LUMEN_RULES
    });
  }

  if (url.pathname === "/vault/recent" && request.method === "GET") {
    return json({
      ok: true,
      service: "Lumen Vault",
      mode: "append-only-scaffold",
      records: [],
      note: "Real persistent writes are added in the next approved Lumen storage layer."
    });
  }

  if (url.pathname === "/vault/append" && request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const record = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      type: body.type || "vault-entry",
      payload: body.payload || body,
      rules: LUMEN_RULES
    };

    return json({
      ok: true,
      service: "Lumen Vault",
      mode: "append-only-scaffold",
      record
    });
  }

  if (url.pathname === "/api/openai/status") {
    return json({
      ok: true,
      provider: "OpenAI",
      configured: !!env.OPENAI_API_KEY,
      note: "OpenAI key must be stored as a Cloudflare secret or through the Lumen setup wizard, never in GitHub."
    });
  }

  return env.ASSETS.fetch(request);
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      ...corsHeaders(),
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}

function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type,authorization,x-vault-key"
  };
}
