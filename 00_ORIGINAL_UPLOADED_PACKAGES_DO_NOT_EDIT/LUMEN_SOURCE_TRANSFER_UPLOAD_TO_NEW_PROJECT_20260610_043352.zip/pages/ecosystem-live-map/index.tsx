export default function Page(){
  return (
    <main style={{
      minHeight:'100vh',
      padding:'32px',
      color:'#fff7df',
      background:'radial-gradient(circle at 8% 92%, rgba(255,184,61,.42), transparent 24%), radial-gradient(circle at 88% 8%, rgba(137,71,255,.45), transparent 30%), linear-gradient(135deg,#07050b,#12071d,#28113a,#08050d)'
    }}>
      <section style={{
        border:'1px solid rgba(255,216,119,.28)',
        borderRadius:'28px',
        padding:'28px',
        background:'linear-gradient(145deg,rgba(19,12,27,.92),rgba(32,14,46,.78))'
      }}>
        <h1 style={{fontFamily:'Georgia,serif',color:'#ffd66d'}}>Brian & Co Ecosystem Live Map™</h1>
        <p style={{fontSize:'18px',lineHeight:'1.7',maxWidth:'980px'}}>Central map for command center, founder approvals, legal portal, supplier systems, income-tier systems, chatbot, accessibility, localization, memberships, products and continuity.</p>
        <p style={{fontSize:'15px',lineHeight:'1.7',maxWidth:'980px'}}>
          Protected Brian & Co material. Additive only. Founder approval required before public, legal, payment, pricing, retired-commerce-platform, OAuth, customer-data, supplier, luxury, OS overwrite, dual boot, driver, firmware, or protected-system changes.
        </p>
      </section>
    </main>
  )
}
